import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numeroSecreto = new Random().nextInt(100);

        int QuantidadesDeTentativas = 20;
        int tentativas = 0;

        System.out.println("Seja bem vindo ao jogo de adivinhacoes!");
        System.out.println("Aqui vao algumas dicas e regras:\n" +
                "----------------------------\n" +
                "É um  numero inteiro\n" +
                "É um numero de 0 a 100\n" +
                "Voce tem 20 tentativas\n" +
                "----------------------------\n");


        while (tentativas != numeroSecreto) {
            System.out.print("Digite seu palpite sobre o numero secreto: ");
            int palpiteNumeroSecreto = sc.nextInt();

            if (palpiteNumeroSecreto == numeroSecreto) {
                System.out.println("Parabens!! Voce acertou o numero secreto: " + numeroSecreto);
                break;

            } else {
                QuantidadesDeTentativas--;
                System.out.println("Poxa, voce errou, mas ainda tem " + QuantidadesDeTentativas + " tentativas.");
                if (QuantidadesDeTentativas == 0) {
                    System.out.println("Poxa, voce perdeu! O numero secreto era: " + numeroSecreto);
                    break;
                }
            }
            
        }




    }
}